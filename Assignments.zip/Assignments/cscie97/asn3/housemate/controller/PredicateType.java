package cscie97.asn3.housemate.controller;

public enum PredicateType {

    PREDICATE_TYPE_JS, PREDICATE_TYPE_BOOLEAN;

}
